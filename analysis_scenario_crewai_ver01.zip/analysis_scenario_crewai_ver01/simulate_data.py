# simulate_chain.py

from tools.custom_tools import (
    generate_structured_request_data_  # manually call logic    
)

def simulate_tool_chain():
    # Step 1: Generate dummy structured request
    structured_request = generate_structured_request_data_()
    print("🔶 Structured Request:")
    print(structured_request)
    
    # # Step 2: Call API simulation tool
    # api_response = get_api_result(structured_request)
    # print("\n🔷 API Response:")
    # print(api_response)
    
    # # Step 3: Generate the full budget scenario
    # df = generate_budget_scenario(api_response)
    # print("\n📊 Budget Scenario DataFrame:")
    # print(df)

if __name__ == "__main__":
    print("Simulate Data")
    simulate_tool_chain()
