import os
import gc
import yaml
from datetime import datetime
from langchain_openai import ChatOpenAI
from crewai import Agent, Task, Crew
#from tools.custom_tools import get_api_result, generate_budget_scenario
from tools.custom_tools import generate_structured_request, get_api_result, generate_budget_scenario


# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = "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"  # Replace with your actual key

class ScenarioAnalysisCrew:
    def __init__(self):
        # Load configs
        with open("agents.yaml", "r") as f:
            self.agents_config = yaml.safe_load(f)
            print("Loaded tasks config:", self.agents_config)

        with open("tasks.yaml", "r") as f:
            self.tasks_config = yaml.safe_load(f)
            print("Loaded tasks config:", self.tasks_config)

        self.llm = ChatOpenAI(model="gpt-4-turbo", temperature=0.3)

        # Set up agent and task
        self.agent = self.create_agent()
        self.task = self.create_task()

        # Create the crew
        self.crew = Crew(
            agents=[self.agent],
            tasks=[self.task],
            verbose=True
        )

    def _timestamp(self):
        from datetime import datetime
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def create_agent(self):
        config = self.agents_config["scenario_builder_executor"]
        return Agent(
            name=config["name"],
            role=config["role"],
            goal=config["goal"],
            backstory=config["backstory"],
            #tools=[get_api_result, generate_budget_scenario],
            tools=[get_api_result, generate_budget_scenario],
            allow_delegation=config["allow_delegation"],
            verbose=config["verbose"],
            max_iter=config["max_iter"],
            llm=self.llm
        )

    def create_task(self):
        config = self.tasks_config["budget_scenario_analysis"]
        timestamped_output_file = config["output_file"].replace(
            "{timestamp}", datetime.now().strftime("%Y%m%d_%H%M%S")
        )
        return Task(
            name=config["name"],
            description=config["description"],
            expected_output=config["expected_output"],
            output_file=timestamped_output_file,
            agent=self.agent
        )

    def run(self):
        #return self.crew.run()
        #return self.crew.execute()
        return self.crew.kickoff() 
