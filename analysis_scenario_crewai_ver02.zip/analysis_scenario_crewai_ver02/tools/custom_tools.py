# tools/custom_tools.py

from crewai.tools import tool
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, Any

# Extracted function for simulation
def generate_structured_request_data_() -> Dict[str, Any]:
    return {
        "business_units": ["Tech COO", "Innovation", "IM IT"],
        "impact_level": "medium",
        "time_horizon": 3,
        "strategic_focus": "Cost Optimization",
        "constraints": {
            "HC_limit": 15000,
            "max_increase_per_year": 0.05,
            "budget_ceiling": 1_000_000_000,
            "headcount_freeze": True
        }
    }

@tool("Generate Structured Request")
def generate_structured_request() -> Dict[str, Any]:  
    """Generates a dummy structured request for budget scenario simulation.

    Returns:
        Dict[str, Any]: A dictionary with business units, impact level, time horizon, strategic focus, and constraints.
    """
    
    return generate_structured_request_data_()

@tool("Get API Result")
def get_api_result(structured_request: Dict[str, Any]) -> Dict[str, Any]:
    """Simulates budget impact API call with structured request.
    
    Args:
        structured_request: Dictionary containing:
            - business_units: List of business units to analyze
            - impact_level: String indicating impact level (high, medium, low)
            - time_horizon: Integer for number of years to project
            - strategic_focus: String describing strategic focus
            - constraints: Dictionary of constraints
            
    Returns:
        dict: API response containing:
            - recommended_years: List of years to project
            - impact_level: Adjusted impact level
            - focus_areas: List of focus areas
            - constraints: Processed constraints
    """
    current_year = datetime.now().year
    years = list(range(current_year, current_year + structured_request["time_horizon"] + 1))

    return {
        "recommended_years": years,
        "impact_level": structured_request["impact_level"],
        "focus_areas": structured_request["business_units"],
        "constraints": structured_request["constraints"],
        "timestamp": datetime.now().isoformat()
    }

@tool("Generate Budget Scenario")
def generate_budget_scenario(api_response: Dict[str, Any]) -> pd.DataFrame:
    """Creates multi-year budget projections based on API response."""
    
    groups = [
        "IM IT", "IM IT-Employees", "IM IT-Contingent",
        "Tech COO-Employees", "Tech COO-Contingent",
        "Innovation-Employees", "Innovation-Contingent"
    ]

    impact_factor = {
        "high": 0.85,
        "medium": 0.95,
        "low": 1.0
    }.get(api_response["impact_level"], 1.0)

    data = {"Group": groups}
    base_values = {
        "Employees": np.array([200, 100, 50, 80, 40, 60, 30]) * 1_000_000 * impact_factor,
        "Contingent": np.array([50, 20, 30, 15, 25, 10, 20]) * 1_000_000 * impact_factor,
        "HC": np.array([8000, 4000, 2000, 3000, 1500, 2000, 1000]) * impact_factor
    }

    for year in api_response["recommended_years"]:
        yearly_factor = 1 + (np.random.rand(len(groups)) * 0.05 - 0.02)

        data[f"{year} Current $"] = (base_values["Employees"] * yearly_factor).astype(int)
        data[f"{year} Current HC"] = (base_values["HC"] * yearly_factor).astype(int)

        adjustment = 1.03 + (np.random.rand(len(groups)) * 0.04)
        data[f"{year} Final $"] = (data[f"{year} Current $"] * adjustment).astype(int)
        data[f"{year} Final HC"] = (data[f"{year} Current HC"] * 0.98).astype(int)

        base_values["Employees"] = data[f"{year} Final $"]
        base_values["HC"] = data[f"{year} Final HC"]

    return pd.DataFrame(data)
