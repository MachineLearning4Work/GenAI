# main.py

from scenario_analysis_crew import ScenarioAnalysisCrew
import os

def main():
    os.makedirs("reports", exist_ok=True)
    crew = ScenarioAnalysisCrew()
    
    print("\n🚀 Starting Scenario Analysis...\n")
    result = crew.run()  # ✅ Run the scenario analysis crew
    print("\n✅ Done! Analysis Results:")
    print(result)

if __name__ == "__main__":
    print("This is a Sample Dummy - Scenario Analysis")
    main()


