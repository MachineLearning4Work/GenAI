# tools/text_tools.py
from crewai_tools import tool

@tool("Text Consolidator")
def consolidate_texts(pdf_text: str, ocr_text: str) -> str:
    """Merges and cleans text from PDF and OCR sources."""
    # Priority to PDF text (assumed cleaner), fallback to OCR
    combined = pdf_text if pdf_text else ocr_text
    # Basic cleanup (customize as needed)
    combined = " ".join(combined.split())  # Remove extra whitespace
    return combined