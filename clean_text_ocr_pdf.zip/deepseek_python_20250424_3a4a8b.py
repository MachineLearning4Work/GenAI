# tools/ocr_tools.py
from crewai_tools import tool
from PIL import Image
import pytesseract

@tool("OCR Text Extractor")
def ocr_extractor(image_path: str) -> str:
    """Extracts text from scanned PDFs/images using Tesseract OCR."""
    try:
        text = pytesseract.image_to_string(Image.open(image_path))
        return text.strip()
    except Exception as e:
        return f"OCR Error: {e}"