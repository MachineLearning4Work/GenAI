# tools/pdf_tools.py
from crewai_tools import tool
import PyPDF2

@tool("PDF Text Extractor")
def pdf_extractor(pdf_path: str) -> str:
    """Extracts text from machine-readable PDFs."""
    text = ""
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text()
        return text.strip()
    except Exception as e:
        return f"PDF Read Error: {e}"