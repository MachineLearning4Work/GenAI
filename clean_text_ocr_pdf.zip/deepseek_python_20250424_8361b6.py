# main.py
from crewai import Agent, Task, Crew
from tools.pdf_tools import pdf_extractor
from tools.ocr_tools import ocr_extractor
from tools.text_tools import consolidate_texts

# --- Define Agents ---
pdf_agent = Agent(
    role="PDF Text Extractor",
    goal="Extract raw text from digital PDFs",
    backstory="Specializes in parsing machine-readable PDFs.",
    tools=[pdf_extractor]  # Assign PDF tool
)

ocr_agent = Agent(
    role="OCR Specialist",
    goal="Extract text from scanned PDFs/images",
    backstory="Uses Tesseract OCR to read non-selectable text.",
    tools=[ocr_extractor]  # Assign OCR tool
)

consolidation_agent = Agent(
    role="Text Cleaner & Merger",
    goal="Merge and clean text from PDF and OCR",
    backstory="Deduplicates and corrects errors in extracted text.",
    tools=[consolidate_texts]  # Assign consolidation tool
)

# --- Define Tasks ---
pdf_task = Task(
    description="Extract text from the PDF at {file_path}",
    agent=pdf_agent,
    expected_output="Raw text extracted from the PDF.",
    tools=[pdf_extractor]  # Explicit tool binding
)

ocr_task = Task(
    description="Extract text from the file {file_path} using OCR",
    agent=ocr_agent,
    expected_output="Raw text extracted via OCR (may contain errors).",
    tools=[ocr_extractor]
)

consolidate_task = Task(
    description="Merge and clean text from PDF and OCR outputs.",
    agent=consolidation_agent,
    expected_output="Final consolidated, clean text.",
    context=[pdf_task, ocr_task],  # Depends on prior tasks
    tools=[consolidate_texts]
)

# --- Run the Crew ---
crew = Crew(
    agents=[pdf_agent, ocr_agent, consolidation_agent],
    tasks=[pdf_task, ocr_task, consolidate_task],
    verbose=2
)

file_path = "sample_document.pdf"  # or image path
result = crew.kickoff(inputs={"file_path": file_path})
print("Final Output:\n", result)